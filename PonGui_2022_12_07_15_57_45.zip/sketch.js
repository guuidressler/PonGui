//Variáveis da bolinha
let xBolinha = 450;
let yBolinha = 350;
let diametro = 35;
let raio = diametro / 2;


//Velocidade da bolinha
let velocidadeXBolinha = 4
let velocidadeYBolinha = 4

//variáveis da raquete
let xRaquete = 5; 
let yRaquete = 295;
let raqueteComprimento = 10;
let raqueteAltura = 115;
let colidiu = false;

//variaáveis do oponente
let xRaqueteOponente = 885;
let yRaqueteOponente = 295;
let velocidadeYOponente;

//Placar do jogo
let meusPontos = 0;
let pontosOponente = 0;

//Sonds do jogo
let raquetada;
let ponto;
let trilha;

function preload(){
  trilha = loadSound("trilha.wav");
  ponto = loadSound("ponto.mp3");
  raquetada = loadSound("raquetada.mp3");
}

function setup() {
  createCanvas(900, 700);
  trilha.loop();
  
}
function draw() { 
  background(0); 
  mostraBolinha();
  movimentaBolinha();
  verificaColisaoBorda();
  mostraRaquete(xRaquete, yRaquete);
  mostraRaquete(xRaqueteOponente, yRaqueteOponente);
  movimentaMinhaRaquete();
  movimentaRaqueteOponente();
  verificaColisaoRaquete(xRaquete, yRaquete);
  verificaColisaoRaquete(xRaqueteOponente, yRaqueteOponente);
  incluirPlacar();
  marcaPonto();
  bolinhaNaoFicaPresa();
}

function mostraBolinha(){
  circle(xBolinha, yBolinha, diametro)
}

function movimentaBolinha (){
  xBolinha += velocidadeXBolinha; 
  yBolinha += velocidadeYBolinha;
}

function verificaColisaoBorda(){
  if (xBolinha + raio > width || 
      xBolinha - raio <0) {
    velocidadeXBolinha *= -1;
}
  
  if (yBolinha + raio> height ||
      yBolinha -raio <0) {
    velocidadeYBolinha *= -1;}
} 

function mostraRaquete (x,y){
  rect(x,y,raqueteComprimento, raqueteAltura);
}

function mostraRaqueteOponente(){
  rect(xRaqueteOponente, yRaqueteOponente,
  raqueteComprimento, raqueteAltura);
}

function movimentaMinhaRaquete(){
  if (keyIsDown(87)){
    yRaquete -= 10;}
  
   if (keyIsDown(83)){
    yRaquete += 10;}
  }   
 
function verificaColisaoRaquete(x, y){
  colidiu = collideRectCircle(x, y, raqueteComprimento, raqueteAltura, xBolinha, yBolinha, diametro);
  if (colidiu){velocidadeXBolinha *= -1; 
  raquetada.play();
  }
}

function movimentaRaqueteOponente(){
  if (keyIsDown(UP_ARROW)){
    yRaqueteOponente -= 10;}

   if (keyIsDown(DOWN_ARROW)){
    yRaqueteOponente += 10;}  
}

function incluirPlacar(){
  stroke(255)
  textAlign(CENTER);
  textSize(30);
  fill(color(218,165,32));
  rect(205, 9, 41, 31);
  fill(255);
  text(meusPontos, 225, 35);
  fill(color(218,165,32));
  rect(655, 9, 41, 31);
  fill(255)
  text(pontosOponente, 675, 35);
  
}

function marcaPonto(){
  if (xBolinha > 885){
    meusPontos += 1;
    ponto.play();
  }
  if (xBolinha < 15){
    pontosOponente += 1;
    ponto.play();
  }
}

function bolinhaNaoFicaPresa(){
    if (xBolinha - raio < 0){
    xBolinha = 20
    }
}
